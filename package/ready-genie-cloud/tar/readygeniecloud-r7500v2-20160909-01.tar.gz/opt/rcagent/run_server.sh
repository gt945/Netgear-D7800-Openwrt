#!/bin/sh

/opt/rcagent/nas_service &
/opt/rcagent/cgi_processor &